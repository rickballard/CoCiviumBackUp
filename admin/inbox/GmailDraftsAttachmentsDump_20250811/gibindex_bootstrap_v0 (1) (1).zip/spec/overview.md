# Spec Overview (v0 2025-08-09)
IDs `gib:<domain>:<slug>` immutable. Monthly signed releases. JSON entries + links. Read API only.
