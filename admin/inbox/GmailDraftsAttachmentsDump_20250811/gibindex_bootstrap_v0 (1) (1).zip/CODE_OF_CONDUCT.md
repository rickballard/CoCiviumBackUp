# Code of Conduct
Disagree hard on merits; no harassment. Follow GitHub standards.
