# GIB Index (GibIndex)
**Language:** GIB. **Registry:** GibIndex. **Status:** Bootstrap v0 (2025-08-09).

GibIndex is a versioned registry of meanings for GIB. Scale (millions), integrity (signed snapshots), interoperability (OntoLex-Lemon, SKOS). Writes via PR; reads via object storage + indexed APIs.
